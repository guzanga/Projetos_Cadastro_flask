from flask import Flask, render_template, request, redirect, session, flash


app = Flask(__name__)
app.secret_key = "Jogaoga"
class cadinflu:
    def __init__(self,nome,plataformas,seguidores,interesses):
        self.nome= nome
        self.plataformas= plataformas
        self.seguidores= seguidores
        self.interesses = interesses

lista = []

@app.route('/influencers')
def influencers():
    if 'usuario_logado' not in session:
        return redirect("/")
    else:
        return render_template("index.html",Titulo= "Influencers cadastrados:", ListaINF=lista)

@app.route('/cadastro')
def cadastro():
    if 'usuario_logado' not in session:
        return redirect("/")
    else:
        return render_template("Cadastro.html",Titulo="Cadastro influencers")


# como aqui usa metodos devo colocar o metodo que a rota ira utilzar
@app.route('/criar', methods=["POST"])
def criar():
    if "salvar" in request.form:
        nome = request.form['nome']
        plataformas = request.form['plataformas']
        seguidores = request.form['seguidores']
        interesses = request.form['interesses']
        obj= cadinflu( nome,plataformas, seguidores, interesses)
        lista.append(obj)
        return redirect("/influencers")
    elif "deslogar" in request.form:
        session.clear()
        return redirect("/")

@app.route('/excluir/<nomeINF>', methods=["GET","DELETE" ])
def excluir(nomeINF):
    for i, inf in enumerate(lista):
        if inf.nome == nomeINF:
            lista.pop(i)
            break
    return redirect("/influencers")

@app.route("/editar/<nomeINF>", methods=["GET"])
def editar(nomeINF):
    for i, inf in enumerate(lista):
        if inf.nome == nomeINF:
            return render_template("Editar.html", influenciador=inf, Titulo= "Alterar influencers:")

@app.route("/alterar", methods= ['POST', 'PUT'])
def alterar():
    nome = request.form['nome']
    for i, inf in enumerate(lista):
        if inf.nome == nome:
            inf.plataformas = request.form['plataformas']
            inf.seguidores = request.form['seguidores']
            inf.interesses = request.form['interesses']
        return redirect('/influencers')

@app.route("/")
def login():
    # limpa a secão
    session.clear()
    return render_template("Login.html", Titulo = "faça seu login")

@app.route("/autenticar", methods=['POST'])
def auntenticar():
    if request.form["usuario"] == "Gustavo" and request.form['senha'] == '123':
        # aqui armazena o nome do usuario em uma seção
        session['usuario_logado'] = request.form['usuario']
        flash('Usuário logado com Sucesso')
        return redirect("/cadastro")
    else:
        # flash coloca na tela uma mensagem
        flash('Usuário não encontrado')
        return redirect('/')

if __name__ == '__main__':
    app.run()
