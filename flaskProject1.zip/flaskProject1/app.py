from flask import Flask, render_template, request, redirect

app = Flask(__name__)
class cadinflu:
    def __init__(self,nome,plataformas,seguidores,interesses):
        self.nome= nome
        self.plataformas= plataformas
        self.seguidores= seguidores
        self.interesses = interesses

lista = []

@app.route('/influencers')
def influencers():
    return render_template("index.html",Titulo= "Influencers cadastrados:", ListaINF=lista)

@app.route('/cadastro')
def cadastro():
    return render_template("Cadastro.html",Titulo="Cadastro influencers")


# como aqui usa metodos devo colocar o metodo que a rota ira utilzar
@app.route('/criar', methods=["POST"])
def criar():
    nome = request.form['nome']
    plataformas = request.form['plataformas']
    seguidores = request.form['seguidores']
    interesses = request.form['interesses']
    obj= cadinflu( nome,plataformas, seguidores, interesses)
    lista.append(obj)
    return redirect("/influencers")

@app.route('/excluir/<nomeINF>', methods=["GET","DELETE" ])
def excluir(nomeINF):
    for i, inf in enumerate(lista):
        if inf.nome == nomeINF:
            lista.pop(i)
            break
    return redirect("/influencers")

@app.route("/editar/<nomeINF>", methods=["GET"])
def editar(nomeINF):
    for i, inf in enumerate(lista):
        if inf.nome == nomeINF:
            return render_template("Editar.html", influenciador=inf, Titulo= "Alterar influencers:")

@app.route("/alterar", methods= ['POST', 'PUT'])
def alterar():
    nome = request.form['nome']
    for i, inf in enumerate(lista):
        if inf.nome == nome:
            inf.plataformas = request.form['plataformas']
            inf.seguidores = request.form['seguidores']
            inf.interesses = request.form['interesses']
        return redirect('/influencers')

if __name__ == '__main__':
    app.run()