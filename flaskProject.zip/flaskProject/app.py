from flask import Flask, render_template, request, redirect, session, flash

app = Flask(__name__)
app.secret_key = "joguinho"
class CardJogadores:
    def __init__(self, nome,jogo , posicao , rank):
        self.nome= nome
        self.jogo= jogo
        self.posicao = posicao
        self.rank = rank

lista = []

@app.route('/jogadores')
def jogadores():
    if 'usuario_logado' not in session:
        return redirect("/")
    else:
        return render_template("index.html", ListaJogadores=lista)

@app.route('/cadastro')
def cadastro():
    if 'usuario_logado' not in session:
        return redirect("/")
    else:
        return render_template("cadastro.html",)


# como aqui usa metodos devo colocar o metodo que a rota ira utilzar
@app.route('/criar', methods=["POST"])
def criar():
    if "salvar" in request.form:
        nome = request.form['nome']
        jogo = request.form['jogo']
        posicao = request.form['posicao']
        rank = request.form['rank']
        obj= CardJogadores( nome, jogo, posicao, rank)
        lista.append(obj)
        return redirect("/jogadores")
    elif "deslogar" in request.form:
        session.clear()
        return redirect("/")

@app.route('/excluir/<nomeVOL>', methods=["GET","DELETE" ])
def excluir(nomeVOL):
    for i, volei in enumerate(lista):
        if volei.nome == nomeVOL:
            lista.pop(i)
            break
    return redirect("/jogadores")

@app.route("/editar/<nomeVOL>", methods=["GET"])
def editar(nomeVOL):
    for i, volei in enumerate(lista):
        if volei.nome == nomeVOL:
            return render_template("Editar.html", VoVo=volei, Titulo= "Alterar jogadores:")

@app.route("/alterar", methods= ['POST', 'PUT'])
def alterar():
    nome = request.form['nome']
    for i, volei in enumerate(lista):
        if volei.nome == nome:
            volei.jogo = request.form['jogo']
            volei.posicao = request.form['posicao']
            volei.rank = request.form['rank']

        return redirect('/jogadores')

@app.route("/")
def login():
    # limpa a secão
    session.clear()
    return render_template("Login.html", Titulo = "faça seu login")

@app.route("/autenticar", methods=['POST'])
def auntenticar():
    if request.form["usuario"] == "Gustavo" and request.form['senha'] == '123':
        # aqui armazena o nome do usuario em uma seção
        session['usuario_logado'] = request.form['usuario']
        flash('Usuário logado com Sucesso')
        return redirect("/cadastro")
    else:
        # flash coloca na tela uma mensagem
        flash('Usuário não encontrado')
        return redirect('/')


if __name__ == '__main__':
    app.run()
