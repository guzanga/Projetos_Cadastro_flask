from flask import Flask, render_template, request, redirect

app = Flask(__name__)
class cadvolei:
    def __init__(self,nome,idade,posicao,nivel,cidade_estado,dias, horarios):
        self.nome= nome
        self.idade= idade
        self.posicao= posicao
        self.nivel = nivel
        self.cidade_estado = cidade_estado
        self.dias = dias
        self.horarios = horarios

lista = []

@app.route('/jogadores')
def influencers():
    return render_template("index.html",Titulo= "Jogadores cadastrados:", ListaVOL=lista)

@app.route('/cadastro')
def cadastro():
    return render_template("cadastro.html",Titulo="Cadastro de Jogadores de volei")


# como aqui usa metodos devo colocar o metodo que a rota ira utilzar
@app.route('/criar', methods=["POST"])
def criar():
    nome = request.form['nome']
    idade = request.form['idade']
    posicao = request.form['posicao']
    nivel = request.form['nivel']
    cidade_estado = request.form['cidade_estado']
    dias = request.form['dias']
    horarios = request.form['horarios']
    obj= cadvolei( nome,idade, posicao, nivel, cidade_estado, dias, horarios)
    lista.append(obj)
    return redirect("/jogadores")

@app.route('/excluir/<nomeVOL>', methods=["GET","DELETE" ])
def excluir(nomeVOL):
    for i, volei in enumerate(lista):
        if volei.nome == nomeVOL:
            lista.pop(i)
            break
    return redirect("/jogadores")

@app.route("/editar/<nomeVOL>", methods=["GET"])
def editar(nomeVOL):
    for i, volei in enumerate(lista):
        if volei.nome == nomeVOL:
            return render_template("Editar.html", VoVo=volei, Titulo= "Alterar jogadores:")

@app.route("/alterar", methods= ['POST', 'PUT'])
def alterar():
    nome = request.form['nome']
    for i, volei in enumerate(lista):
        if volei.nome == nome:
            volei.idade = request.form['idade']
            volei.posicao = request.form['posicao']
            volei.nivel = request.form['nivel']
            volei.cidade_estado = request.form['cidade_estado']
            volei.dias = request.form['dias']
            volei.horarios = request.form['horarios']
        return redirect('/jogadores')

if __name__ == '__main__':
    app.run()
